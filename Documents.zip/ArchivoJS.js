if(document.getElementById("enviar").value==" ")
{
  alert("El campo esta vacío, llenalo");
}